﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;

namespace SocketsClient
{
    public partial class SocketsTest : Form
    {
        public System.Net.Sockets.Socket clientSocket { get; set; }

        public SocketsTest()
        {
            InitializeComponent();
        }

        private void SetMessage(string message)
        {
            this.label3.Text = message;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.clientSocket != null && this.clientSocket.Connected )
                {
                    return;
                }
                IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(SocketsClient.Properties.Settings.Default.ServerAddress), SocketsClient.Properties.Settings.Default.Port);
                this.clientSocket = new Socket(ipep.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                clientSocket.Connect(ipep);
            }
            catch (Exception ex)
            {

                SetMessage("发送消息错误！" + ex.Message);
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {             


                Byte[] outBuffer  =  Encoding.Default .GetBytes( this.textBox1.Text);    

                    //发送消息  
                    clientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
            }

            catch(Exception ex)
            {

                SetMessage("发送消息错误！"+ ex.Message );

            }
        }

        private void SocketsTest_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.clientSocket != null)
            {
                if (this.clientSocket.Connected)
                {
                    this.clientSocket.Close();
                }
            }
        }
    }
}
